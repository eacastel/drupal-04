<?php

namespace Drupal\entity_module_bundle_plugin_test\Plugin\BundlePluginTest;

use Drupal\entity\BundlePlugin\BundlePluginInterface;

/**
 * Defines the interface for BundlePluginTest plugins.
 */
interface BundlePluginTestInterface extends BundlePluginInterface {

}
